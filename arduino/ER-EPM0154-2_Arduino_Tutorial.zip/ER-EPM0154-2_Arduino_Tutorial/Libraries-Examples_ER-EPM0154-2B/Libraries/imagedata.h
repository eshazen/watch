/***************************************************
//Web: http://www.buydisplay.com
EastRising Technology Co.,LTD
****************************************************/

extern const unsigned char IMAGE_DATA[];
extern const unsigned char IMAGE_DATA1[];

/* FILE END */


